<?php

namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use App\Models\Setting;
use Exception;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        /*try {
            // Attempt to fetch the active theme from the database settings table.
            // This is wrapped in a try/catch to prevent errors before the database is migrated.
            $activeTheme = Setting::where('name', 'active_theme')->first();
            $themePath = $activeTheme ? $activeTheme->value : 'default';

            // Add the dynamic path to the view configuration.
            // The path will be resources/views/templates/{theme_name}
            View::addLocation(resource_path("views/templates/{$themePath}"));

        } catch (Exception $e) {
            // Log or handle the exception if the settings table does not exist yet (during initial migration).
            // For now, we allow the default 'resources/views' to handle the view loading until DB is ready.
            // logger("Theme setting error: " . $e->getMessage());
        }*/
    }
}